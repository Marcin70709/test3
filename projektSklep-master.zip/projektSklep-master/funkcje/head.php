<?php
/*
 *  plik zawiera sekcję <head> z <html>
 */
?>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Projekt Sklep</title>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="bootstrap/css/flat-ui.css" rel="stylesheet">
    </head>